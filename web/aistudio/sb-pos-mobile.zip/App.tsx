import React, { useState } from 'react';
import { BottomNav } from './components/BottomNav';
import { DashboardView } from './components/views/DashboardView';
import { OrdersView } from './components/views/OrdersView';
import { Logo } from './components/Logo';
import { AppTab } from './types';
import { Bell, User } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.DASHBOARD);
  const [showAddModal, setShowAddModal] = useState(false);

  // Main Content Switcher
  const renderContent = () => {
    switch (activeTab) {
      case AppTab.DASHBOARD:
        return <DashboardView />;
      case AppTab.ORDERS:
        return <OrdersView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 font-sans flex justify-center">
      <div className="w-full max-w-md bg-[#f8fafc] shadow-2xl min-h-screen relative flex flex-col">
        
        {/* Top App Bar */}
        <header className="bg-white px-6 py-4 flex justify-between items-center shadow-sm z-20 sticky top-0">
          <Logo className="scale-75 origin-left" />
          <div className="flex space-x-3">
             <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-colors relative">
                <Bell size={20} />
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
             </button>
             <button className="w-9 h-9 bg-slate-100 rounded-full flex items-center justify-center text-[#1e40af] font-bold border border-slate-200">
                JD
             </button>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 relative overflow-hidden">
             {renderContent()}
        </main>

        {/* Floating Action Modal (Simulation) */}
        {showAddModal && (
          <div className="absolute inset-0 z-50 flex items-end justify-center bg-black/50 animate-fade-in backdrop-blur-sm">
            <div className="bg-white w-full rounded-t-3xl p-6 pb-24 space-y-6 animate-slide-up">
                <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto mb-2"></div>
                <h3 className="text-xl font-bold text-center text-slate-800">New Transaction</h3>
                
                <div className="grid grid-cols-2 gap-4">
                    <button className="p-4 bg-blue-50 rounded-2xl flex flex-col items-center justify-center space-y-2 border border-blue-100 active:scale-95 transition-transform">
                        <div className="w-10 h-10 bg-[#1e40af] rounded-full flex items-center justify-center text-white">
                            <span className="text-lg font-bold">D</span>
                        </div>
                        <span className="text-sm font-semibold text-[#1e40af]">Dine In</span>
                    </button>
                    <button className="p-4 bg-orange-50 rounded-2xl flex flex-col items-center justify-center space-y-2 border border-orange-100 active:scale-95 transition-transform">
                        <div className="w-10 h-10 bg-[#f97316] rounded-full flex items-center justify-center text-white">
                            <span className="text-lg font-bold">T</span>
                        </div>
                        <span className="text-sm font-semibold text-[#f97316]">Take Away</span>
                    </button>
                </div>

                <button 
                    onClick={() => setShowAddModal(false)}
                    className="w-full py-3 text-slate-500 font-medium text-sm hover:text-slate-800"
                >
                    Cancel
                </button>
            </div>
          </div>
        )}

        {/* Bottom Navigation */}
        <BottomNav 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
          onAddClick={() => setShowAddModal(true)}
        />
      </div>

      <style>{`
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slide-up {
            from { transform: translateY(100%); }
            to { transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
        }
        .animate-slide-up {
            animation: slide-up 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
};

export default App;