import React from 'react';
import { TrendingUp, Users, DollarSign, ShoppingBag } from 'lucide-react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { CHART_DATA } from '../../constants';
import { StatCardProps } from '../../types';

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, colorClass, trend, isPositive }) => (
  <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-32">
    <div className="flex justify-between items-start">
      <div className={`p-2 rounded-xl ${colorClass} bg-opacity-10`}>
        {React.cloneElement(icon as React.ReactElement, { size: 20, className: colorClass.replace('bg-', 'text-') })}
      </div>
      {trend && (
        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${isPositive ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
          {trend}
        </span>
      )}
    </div>
    <div>
      <p className="text-slate-400 text-xs font-medium uppercase tracking-wide">{title}</p>
      <h3 className="text-xl font-bold text-slate-800 mt-1">{value}</h3>
    </div>
  </div>
);

export const DashboardView: React.FC = () => {
  return (
    <div className="pb-24 pt-4 px-4 space-y-6 animate-fade-in">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-2xl font-bold text-slate-800">Overview</h2>
        <div className="text-sm text-slate-500 bg-white px-3 py-1 rounded-full shadow-sm border border-slate-100">Today</div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <StatCard 
          title="Total Sales" 
          value="Rp 2.4M" 
          icon={<DollarSign />} 
          colorClass="bg-[#1e40af]" 
          trend="+12%" 
          isPositive={true}
        />
        <StatCard 
          title="Total Orders" 
          value="45" 
          icon={<ShoppingBag />} 
          colorClass="bg-[#f97316]"
          trend="+5%"
          isPositive={true}
        />
        <StatCard 
          title="Customers" 
          value="128" 
          icon={<Users />} 
          colorClass="bg-blue-500"
        />
        <StatCard 
          title="Avg. Order" 
          value="Rp 54k" 
          icon={<TrendingUp />} 
          colorClass="bg-emerald-500"
        />
      </div>

      {/* Chart Section */}
      <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 mb-6">Weekly Revenue</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={CHART_DATA}>
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 12, fill: '#94a3b8' }} 
                dy={10}
              />
              <Tooltip 
                cursor={{ fill: '#f1f5f9' }}
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Bar dataKey="sales" radius={[4, 4, 0, 0]}>
                {CHART_DATA.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === 2 ? '#f97316' : '#1e40af'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Quick Action Promo */}
      <div className="bg-gradient-to-r from-[#1e40af] to-blue-600 rounded-2xl p-5 text-white shadow-lg shadow-blue-500/30">
        <div className="flex justify-between items-center">
          <div>
            <p className="font-semibold text-lg">Pro Plan</p>
            <p className="text-blue-100 text-xs mt-1">Unlock advanced analytics today.</p>
          </div>
          <button className="bg-white text-blue-700 px-4 py-2 rounded-lg text-sm font-bold shadow-sm">
            Upgrade
          </button>
        </div>
      </div>
    </div>
  );
};