import React from 'react';
import { Search, Filter, ChevronRight, Clock, Package } from 'lucide-react';
import { RECENT_ORDERS } from '../../constants';

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const styles: Record<string, string> = {
    completed: 'bg-green-100 text-green-700',
    pending: 'bg-orange-100 text-orange-700',
    cancelled: 'bg-red-100 text-red-700'
  };

  return (
    <span className={`px-2 py-1 rounded-md text-[10px] uppercase font-bold tracking-wide ${styles[status] || 'bg-gray-100 text-gray-700'}`}>
      {status}
    </span>
  );
};

export const OrdersView: React.FC = () => {
  return (
    <div className="pb-24 pt-4 px-4 h-full flex flex-col animate-fade-in">
      {/* Header & Search */}
      <div className="sticky top-0 bg-[#f8fafc] z-10 pb-4 space-y-4">
        <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-800">Orders</h2>
            <button className="p-2 bg-white rounded-full border border-slate-200 text-slate-500">
                <Filter size={20} />
            </button>
        </div>
        
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search order ID, customer..." 
            className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316]/50 transition-all shadow-sm"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
        </div>
      </div>

      {/* Order List */}
      <div className="flex-1 overflow-y-auto no-scrollbar space-y-3">
        {RECENT_ORDERS.map((order) => (
          <div key={order.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 active:scale-[0.99] transition-transform duration-100 cursor-pointer">
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center space-x-2">
                <span className="font-bold text-[#1e40af] text-sm">{order.id}</span>
                <StatusBadge status={order.status} />
              </div>
              <span className="text-xs text-slate-400 font-medium flex items-center">
                <Clock size={12} className="mr-1" /> {order.time}
              </span>
            </div>
            
            <div className="flex justify-between items-center">
                <div>
                    <h4 className="font-semibold text-slate-800 text-sm">{order.customer}</h4>
                    <p className="text-xs text-slate-500 flex items-center mt-1">
                        <Package size={12} className="mr-1" /> {order.items} Items
                    </p>
                </div>
                <div className="text-right">
                    <p className="font-bold text-[#f97316]">Rp {order.amount.toLocaleString()}</p>
                    <div className="flex items-center justify-end mt-1 text-slate-400">
                        <span className="text-xs mr-1">Details</span>
                        <ChevronRight size={14} />
                    </div>
                </div>
            </div>
          </div>
        ))}

        <div className="text-center py-8">
            <p className="text-slate-400 text-xs">End of list</p>
        </div>
      </div>
    </div>
  );
};