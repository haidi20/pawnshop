import React from 'react';
import { Home, ListOrdered, Plus } from 'lucide-react';
import { AppTab } from '../types';

interface BottomNavProps {
  activeTab: AppTab;
  onTabChange: (tab: AppTab) => void;
  onAddClick: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange, onAddClick }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 h-20 bg-white shadow-[0_-4px_20px_rgba(0,0,0,0.05)] rounded-t-2xl z-50 flex items-center justify-between px-8 max-w-md mx-auto w-full">
      
      {/* Left Menu: Dashboard */}
      <button 
        onClick={() => onTabChange(AppTab.DASHBOARD)}
        className={`flex flex-col items-center justify-center space-y-1 transition-colors duration-200 ${
          activeTab === AppTab.DASHBOARD ? 'text-[#1e40af]' : 'text-gray-400'
        }`}
      >
        <Home size={24} strokeWidth={activeTab === AppTab.DASHBOARD ? 2.5 : 2} />
        <span className="text-xs font-medium">Dashboard</span>
      </button>

      {/* Center Floating Button */}
      <div className="relative -top-6">
        <button 
          onClick={onAddClick}
          className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#f97316] to-[#fb923c] shadow-lg shadow-orange-500/40 flex items-center justify-center transform transition-transform duration-150 active:scale-95 border-4 border-[#f8fafc]"
        >
          <Plus size={32} color="white" strokeWidth={3} />
        </button>
      </div>

      {/* Right Menu: Orders */}
      <button 
        onClick={() => onTabChange(AppTab.ORDERS)}
        className={`flex flex-col items-center justify-center space-y-1 transition-colors duration-200 ${
          activeTab === AppTab.ORDERS ? 'text-[#1e40af]' : 'text-gray-400'
        }`}
      >
        <ListOrdered size={24} strokeWidth={activeTab === AppTab.ORDERS ? 2.5 : 2} />
        <span className="text-xs font-medium">Orders</span>
      </button>

    </div>
  );
};