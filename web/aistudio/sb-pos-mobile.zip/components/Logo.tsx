import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "" }) => {
  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      {/* Abstract Shape Representation */}
      <div className="flex items-center mb-1">
        {/* The 'S' Shape (Blue) */}
        <div className="h-8 w-8 bg-[#1e40af] rounded-l-lg rounded-tr-lg mr-1 flex items-center justify-center">
            <span className="text-white font-bold text-xl">S</span>
        </div>
        {/* The 'B' Shape (Orange) */}
        <div className="h-8 w-8 bg-[#f97316] rounded-r-lg rounded-bl-lg flex items-center justify-center">
            <span className="text-white font-bold text-xl">B</span>
        </div>
      </div>
      {/* Text */}
      <div className="text-[#1e40af] font-black tracking-widest text-lg leading-none">
        POS
      </div>
    </div>
  );
};