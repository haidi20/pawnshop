import { Order } from './types';

export const RECENT_ORDERS: Order[] = [
  { id: '#ORD-001', customer: 'Budi Santoso', amount: 150000, status: 'completed', items: 3, time: '10:30 AM' },
  { id: '#ORD-002', customer: 'Siti Aminah', amount: 45000, status: 'pending', items: 1, time: '11:15 AM' },
  { id: '#ORD-003', customer: 'Joko Anwar', amount: 230000, status: 'completed', items: 5, time: '11:45 AM' },
  { id: '#ORD-004', customer: 'Rina Nose', amount: 89000, status: 'cancelled', items: 2, time: '12:20 PM' },
  { id: '#ORD-005', customer: 'Ahmad Dani', amount: 120000, status: 'completed', items: 4, time: '01:05 PM' },
];

export const CHART_DATA = [
  { name: 'Mon', sales: 4000 },
  { name: 'Tue', sales: 3000 },
  { name: 'Wed', sales: 2000 },
  { name: 'Thu', sales: 2780 },
  { name: 'Fri', sales: 1890 },
  { name: 'Sat', sales: 2390 },
  { name: 'Sun', sales: 3490 },
];
