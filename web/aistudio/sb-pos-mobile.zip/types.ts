import React from 'react';

export enum AppTab {
  DASHBOARD = 'dashboard',
  ORDERS = 'orders',
  ADD = 'add'
}

export interface Order {
  id: string;
  customer: string;
  amount: number;
  status: 'completed' | 'pending' | 'cancelled';
  items: number;
  time: string;
}

export interface StatCardProps {
  title: string;
  value: string;
  trend?: string;
  isPositive?: boolean;
  icon: React.ReactNode;
  colorClass: string;
}